<?php

/*
Plugin Name: Harington Gutenberg Blocks
Plugin URI: https://clapat.com/
Description: Gutenberg editor blocks for Harington WordPress Theme
Version: 1.0
Author: ClaPat
Author URI: https://clapat.com/
*/

defined( 'ABSPATH' ) || exit;

include 'blocks/index.php';
